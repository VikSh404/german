briet, hat gebraten
du - brätst
sie - brät

#unreg
# Synonyme

# Verbindung 
[[der Braten]]

# Beispiele
1. **Ich brate das Fleisch in der Pfanne.**  
    — Я жарю мясо на сковороде.
    
2. **Er brät heute Kartoffeln.**  
    — Он сегодня жарит картошку.
    
3. **Wir haben Fisch gebraten.**  
    — Мы пожарили рыбу.
    
4. **Meine Mutter briet gestern ein Schnitzel.**  
    — Моя мама вчера жарила шницель.
# Übersetzung
жарить