#pronomen
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 13:49
# Synonyme

# Verbindung 
[[alles]]
# Beispiele
- **Alle sind müde.**  
    — Все устали.
    
- **Ich habe alle gesehen.**  
    — Я всех видел.
    
- **Danke an alle!**  
    — Спасибо всем!
    
- **Ich vertraue allen meinen Freunden.**  
    — Я доверяю всем своим друзьям.
    
- **Alle Kinder haben Spaß.**  
    — Все дети веселятся.
# Übersetzung
**alle** – все (о людях, предметах, существах во множественном числе)