#adverb
# Synonyme

# Verbindung 
[[sauer]]
[[salzig]]
[[die Süße]]
# Beispiele
1. **Der Kuchen ist sehr süß.**  
    — Пирог очень сладкий.
    
2. **Ich trinke meinen Tee nicht süß.**  
    — Я не пью сладкий чай.
    
3. **Diese Bonbons sind zu süß für mich.**  
    — Эти конфеты для меня слишком сладкие.
    
4. **Dein Hund ist so süß!**  
    — Твоя собака такая милая!
    
5. **Was für ein süßes Baby!**  
    — Какой милый ребёнок!
# Übersetzung
сладкий, милый, симпатичный