die Nudeln
#nomen
# Synonyme

# Verbindung 
[[das Essen]]
# Beispiele
- **Ich koche heute Nudeln mit Tomatensauce.**  
    (Сегодня я готовлю макароны с томатным соусом.)
    
- **Magst du italienische Nudeln?**  
    (Ты любишь итальянскую пасту?)
    
- **Die Nudeln sind noch nicht fertig.**  
    (Макароны ещё не готовы.)
    
- **Kinder essen gern Nudeln.**  
    (Дети любят есть макароны.)
# Übersetzung
лапша, макаронина – макароны, паста