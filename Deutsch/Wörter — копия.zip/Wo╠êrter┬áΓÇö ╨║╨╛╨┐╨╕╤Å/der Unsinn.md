-
Универсальное слово — подходит и в **нейтральных**, и в **недовольных** ситуациях
#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:06
# Synonyme

# Verbindung 
[[sprechen]]
[[reden]]
# Beispiele
- **Das ist doch Unsinn!**  
    (Да это же ерунда!)
    
- **Er hat Unsinn gemacht.**  
    (Он натворил глупостей.)
    
- **Gib dein Geld nicht für Unsinn aus.**  
    (Не трать деньги на ерунду.)
    
- **Kindischer Unsinn!**  
    (Детская глупость!)
# Übersetzung
ерунда, чепуха, глупость, бессмыслица
