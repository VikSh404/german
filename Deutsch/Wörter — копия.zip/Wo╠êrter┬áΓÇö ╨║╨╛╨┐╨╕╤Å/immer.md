#adverb
# Synonyme

# Verbindung 
[[die Zeit]]
[[morgen]]
[[fast immer]]
[[fast]]
[[selten]]
[[manchmal]]
[[immer]]
[[nie]]
[[oft]]
# Beispiele
🔹 **Ich bin immer müde.**  
(Я всегда устаю.)

🔹 **Er kommt immer zu spät.**  
(Он всегда опаздывает.)

🔹 **Sie hat immer gute Laune.**  
(У неё всегда хорошее настроение.)

🔹 **Es wird immer besser.**  
(Всё становится всё лучше.)

🔹 **Ich warte immer noch.**  
(Я всё ещё жду.)
# Übersetzung
- **всегда**
- **всё время**, **постоянно**
- также: **всё ещё** (в связках, напр. _immer noch_)