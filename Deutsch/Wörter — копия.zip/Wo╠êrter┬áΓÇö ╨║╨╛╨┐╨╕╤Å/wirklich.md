#adverb
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:29
# Synonyme

# Verbindung 

# Beispiele
- **Ich bin wirklich müde.**  
    — Я действительно устал.
    
- **Du hast das wirklich selbst gemacht?**  
    — Ты правда сам это сделал?
    
- **Der Film war wirklich spannend.**  
    — Фильм был действительно захватывающий.
    
- **Wirklich? Das wusste ich nicht!**  
    — Правда? Я этого не знал!
# Übersetzung
действительно / на самом деле / правда