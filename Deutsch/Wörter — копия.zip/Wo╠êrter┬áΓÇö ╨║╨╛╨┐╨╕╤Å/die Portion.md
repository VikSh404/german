die Portionen
#nomen
# Synonyme

# Verbindung
[[das Gericht]]
[[die Speise]]
# Beispiele
- **Ich hätte gern eine Portion Pommes.**  
    (Я бы хотел одну порцию картошки фри.)
    
- **Diese Portion ist zu groß für mich.**  
    (Эта порция слишком большая для меня.)
    
- **Zwei Portionen Eis, bitte.**  
    (Две порции мороженого, пожалуйста.)
    
- **Er isst jeden Tag große Portionen.**  
    (Он ест большие порции каждый день.)
# Übersetzung
порция