schrieb auf - hat aufgeschrieben
du - schreibst auf
sie - schreibt auf

#unreg
# Synonyme

# Verbindung 
[[merken]]
# Beispiele
Du schreibst alles auf. (Ты всё записываешь.)
Sie schreibt ihre Aufgaben auf. (Она записывает свои задания.)
Sie schreiben die Wörter auf. (Они записывают слова.)
Schreiben Sie bitte Ihre E-Mail-Adresse auf. (Пожалуйста, запишите свой email.)
# Übersetzung
записывать