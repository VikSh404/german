sah fern, hat ferngesehen
#unreg 
# Synonyme

# Verbindung 

# Beispiele
- **Du siehst jeden Abend fern.**  
    (Ты каждый вечер смотришь телевизор.)
    
- **Sie sieht gerade fern.**  
    (Она сейчас смотрит телевизор.)
    
- **Habt ihr gestern ferngesehen?**  
    (Вы вчера смотрели телевизор?)
# Übersetzung
телевидение