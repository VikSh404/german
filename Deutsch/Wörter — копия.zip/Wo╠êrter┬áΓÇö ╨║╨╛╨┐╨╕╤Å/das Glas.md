die Gläser
#nomen
# Synonyme

# Verbindung 
[[das Getränk]]
[[das Geschirr]]
# Beispiele
🔹 **Ich trinke ein Glas Wasser.**  
(Я пью стакан воды.)

🔹 **Stell das Glas bitte auf den Tisch.**  
(Поставь, пожалуйста, стакан на стол.)

🔹 **Wir brauchen mehr Gläser für die Party.**  
(Нам нужно больше стаканов для вечеринки.)

🔹 **Dieses Glas ist aus Kristall.**  
(Этот бокал из хрусталя.)

🔹 **Ich habe ein Glas Marmelade gekauft.**  
(Я купил банку варенья.)
# Übersetzung
- **стакан** (или бокал)
- **банка** (чаще стеклянная — напр., с мёдом, вареньем)
- **стекло** (материал)