die Wochen
#nomen
# Synonyme

# Verbindung 

# Beispiele
🔹 **Ich arbeite fünf Tage in der Woche.**  
(Я работаю пять дней в неделю.)

🔹 **Die Woche hat sieben Tage.**  
(В неделе семь дней.)

🔹 **Wir fahren nächste Woche nach Wien.**  
(Мы едем в Вену на следующей неделе.)

🔹 **Diese Woche ist sehr stressig.**  
(Эта неделя очень напряжённая.)
# Übersetzung
неделя