die Hobbys

#nomen
# Synonyme

# Verbindung 
[[der Sport]]
[[der Mensch]]
# Beispiele
- **Mein Hobby ist Gitarre spielen.**  
    — Моё хобби — играть на гитаре.
    
- **Hast du ein interessantes Hobby?**  
    — У тебя есть интересное хобби?
    
- **Seine Hobbys sind Sport und Kochen.**  
    — Его хобби — спорт и кулинария.
    
- **In meiner Freizeit widme ich mich meinen Hobbys.**  
    — В свободное время я посвящаю себя своим увлечениям.
# Übersetzung
хобби