Используется с **Dativ + Akkusativ** или **über + Akkusativ**
#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 14:01
# Synonyme

# Verbindung 
[[fragen]]
[[die Geschichte]]
[[reden]]
[[sprechen]]
[[das Buch]]
# Beispiele
- **Er erzählt eine Geschichte.**  
    (Он рассказывает историю.)
    
- **Oma erzählt den Kindern ein Märchen.**  
    (Бабушка рассказывает детям сказку.)
    
- **Erzählt sie über ihren Urlaub?**  
    (Она рассказывает о своём отпуске?)
    
- **Kannst du mir mehr erzählen?**  
    (Ты можешь рассказать мне больше?)
# Übersetzung
рассказывать