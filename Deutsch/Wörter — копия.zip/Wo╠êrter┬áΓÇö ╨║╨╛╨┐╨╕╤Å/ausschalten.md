#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 11:56
# Synonyme
[[ausmachen]]
# Verbindung 
[[anmachen]]
[[die Steckdose]]
[[einschalten]]
# Beispiele
- **Kannst du bitte das Licht ausschalten?**  
    — Можешь, пожалуйста, выключить свет?
    
- **Ich habe den Computer ausgeschaltet.**  
    — Я выключил компьютер.
    
- **Vergiss nicht, den Fernseher auszuschalten!**  
    — Не забудь выключить телевизор!
    
- **Er schaltet das Handy vor dem Unterricht aus.**  
    — Он выключает телефон перед занятием.
# Übersetzung
выключить