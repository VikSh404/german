die Teller
#nomen
# Synonyme

# Verbindung 
[[das Geschirr]]
# Beispiele
🔹 **Der Teller ist leer.**  
(Тарелка пустая.)

🔹 **Ich stelle den Teller auf den Tisch.**  
(Я ставлю тарелку на стол.)

🔹 **Wie viele Teller brauchst du?**  
(Сколько тебе нужно тарелок?)

🔹 **Die Teller sind in der Spülmaschine.**  
(Тарелки в посудомоечной машине.)
# Übersetzung
тарелка