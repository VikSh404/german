die Rezepte
#nomen
# Synonyme

# Verbindung 
[[die Speise]]
[[das Gericht]]
# Beispiele
- **Hast du ein gutes Rezept für Apfelkuchen?**  
    (У тебя есть хороший рецепт яблочного пирога?)
    
- **Ich koche nach dem Rezept meiner Oma.**  
    (Я готовлю по рецепту моей бабушки.)
    
- **In diesem Rezept braucht man viel Knoblauch.**  
    (В этом рецепте нужно много чеснока.)
    
- **Der Arzt hat mir ein Rezept verschrieben.**  
    (Врач выписал мне рецепт.)
    
- **Dieses Medikament gibt es nur auf Rezept.**  
    (Это лекарство отпускается только по рецепту.)
# Übersetzung
- **рецепт (кулинарный)**
- **рецепт (медицинский)**