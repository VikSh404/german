die Bohnen
#nomen
# Synonyme

# Verbindung 
[[das Gericht]]
# Beispiele
- **Ich esse gern grüne Bohnen.**  
    (Я люблю зелёную фасоль.)
    
- **Die Suppe enthält weiße Bohnen.**  
    (Суп содержит белую фасоль.)
    
- **Wie viele Bohnen brauchst du?**  
    (Сколько фасолин тебе нужно?)
    
- **Bohnen sind reich an Eiweiß.**  
    (Фасоль богата белком.)
# Übersetzung
фасолина / фасоль – фасоли (бобы)