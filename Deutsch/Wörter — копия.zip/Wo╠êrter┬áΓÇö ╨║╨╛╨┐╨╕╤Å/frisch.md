#adverb
# Synonyme

# Verbindung
[[fett]]
[[die Speise]]

die Frische – свежесть

frisch gebacken – свежеиспечённый

frisch gepresster Saft – свежевыжатый сок

frisch verliebt – недавно влюблённый

frisch geduscht – только что принявший душ
# Beispiele
- **Das Brot ist noch frisch.**  
    — Хлеб ещё свежий.
    
- **Ich liebe frisches Obst.**  
    — Я люблю свежие фрукты.
    
- **Die Luft hier ist so frisch.**  
    — Воздух здесь такой свежий.
    
- **Hast du frische Milch?**  
    — У тебя есть свежее молоко?
# Übersetzung
свежий