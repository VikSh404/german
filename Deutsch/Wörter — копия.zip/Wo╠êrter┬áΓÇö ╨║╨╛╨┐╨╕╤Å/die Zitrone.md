die Zitronen
#nomen
# Synonyme

# Verbindung 
[[die Speise]]
[[der Tee]]
[[der Kaffee]]

der Zitronensaft – лимонный сок
die Zitronenschale – цедра
zitronig – лимонный (на вкус/запах)
die Zitronenlimonade – лимонад
# Beispiele
- **Die Zitrone ist sauer.**  
    — Лимон кислый.
    
- **Ich kaufe zwei Zitronen.**  
    — Я покупаю два лимона.
    
- **Magst du Zitronensaft?**  
    — Ты любишь лимонный сок?
    
- **Sie hat eine Scheibe Zitrone in den Tee gelegt.**  
    — Она положила дольку лимона в чай.
# Übersetzung
лимон