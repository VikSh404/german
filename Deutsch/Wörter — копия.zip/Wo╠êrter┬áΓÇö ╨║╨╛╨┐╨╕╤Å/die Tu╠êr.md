die Türen
#nomen
# Synonyme

# Verbindung 
[[aufmachen]]
[[öffnen]]
[[schließen]]
[[zumachen]]
# Beispiele

# Übersetzung
