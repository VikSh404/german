#adverb
# Synonyme

# Verbindung 
[[frisch]]

[[das Salz]] – соль

[[salzfrei]] – без соли

der Salzgehalt – содержание соли

salzen (глагол) – солить

übersalzen – пересолить
# Beispiele
1. **Die Suppe ist zu salzig.**  
    — Суп слишком солёный.
    
2. **Ich mag salzige Snacks.**  
    — Я люблю солёные закуски.
    
3. **Diese Nüsse sind salziger als die anderen.**  
    — Эти орехи солонее, чем другие.
    
4. **Salziges Wasser ist nicht trinkbar.**  
    — Солёную воду пить нельзя.
# Übersetzung
солёный