-
#nomen
# Synonyme

# Verbindung 
[[das Lied]]
[[das Hobby]]
[[die Melodie]]
# Beispiele
- **Ich höre gern Musik.**  
    — Я люблю слушать музыку.
    
- **Die Musik ist sehr laut.**  
    — Музыка очень громкая.
    
- **Welche Musik gefällt dir?**  
    — Какая музыка тебе нравится?
    
- **Sie macht elektronische Musik.**  
    — Она делает электронную музыку.
# Übersetzung
музыка