die Haare
#nomen
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 13:29
# Synonyme

# Verbindung 
[[lassen]]
[[der Mensch]]

# Beispiele

|Русский|Немецкий|
|---|---|
|Я подстригаю волосы.|**Ich lasse mir die Haare schneiden.**|
|Она подстригает волосы.|**Sie lässt sich die Haare schneiden.**|
|Можете меня подстричь?|**Können Sie mir die Haare schneiden?**|
|Я бы хотел подстричься.|**Ich möchte mir die Haare schneiden lassen.**|
|Я записан на стрижку.|**Ich habe einen Termin zum Haareschneiden.**|
|Можно постричься без записи?|**Kann man sich auch ohne Termin die Haare schneiden lassen?**|
|Сколько стоит стрижка?|**Was kostet ein Haarschnitt?**|
|Я хочу коротко постричься.|**Ich möchte meine Haare kurz schneiden lassen.**|
|Только кончики, пожалуйста.|**Nur die Spitzen, bitte.**|
|Не слишком коротко, пожалуйста.|**Nicht zu kurz, bitte.**|
|Вы довольны?|**Sind Sie zufrieden?**|
|Да, спасибо, очень хорошо.|**Ja, danke, sehr gut.**|

- **Ich wasche mir die Haare.**  
    — Я мою себе волосы.
    
- **Sie hat lange, glatte Haare.**  
    — У неё длинные, прямые волосы.
    
- **Lässt du dir die Haare schneiden?**  
    — Ты подстригаешь волосы?
    
- **Er hat sich die Haare färben lassen.**  
    — Он покрасил волосы (через кого-то / в салоне).
    
- **Nach dem Duschen kämme ich meine Haare.**  
    — После душа я расчёсываю волосы.
# Übersetzung
волос