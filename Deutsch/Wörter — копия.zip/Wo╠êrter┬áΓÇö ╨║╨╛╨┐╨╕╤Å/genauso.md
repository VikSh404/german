#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:30
# Synonyme
[[gleich]]
# Verbindung 

# Beispiele
- **Ich denke genauso wie du.**  
    — Я думаю точно так же, как ты.
    
- **Sie sieht genauso aus wie ihre Mutter.**  
    — Она выглядит точно так же, как её мама.
    
- **Mach es genauso!**  
    — Сделай это точно так же!
    
- **Das war genauso schlimm wie gestern.**  
    — Это было так же плохо, как и вчера.
    
- **Ich will es genauso machen.**  
    — Я хочу сделать это точно так же.
# Übersetzung
точно так же, в точности так, так же как