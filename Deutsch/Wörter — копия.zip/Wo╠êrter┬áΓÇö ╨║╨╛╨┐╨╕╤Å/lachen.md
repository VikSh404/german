#reg
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:20
# Synonyme

# Verbindung 
[[lustig]]
# Beispiele
1. **Ich lache gern.**  
    — Я люблю смеяться.
    
2. **Warum lachst du?**  
    — Почему ты смеёшься?
    
3. **Sie lacht über den Witz.**  
    — Она смеётся над шуткой.
    
4. **Wir haben viel gelacht.**  
    — Мы много смеялись.
# Übersetzung
смеяться