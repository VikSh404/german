traf, hat getroffen
du - triffst
sie - trifft 

		jemanden treffen (Akkusativ) – встретить кого-то
		sich treffen mit + Dativ – встретиться с кем-то (взаимно)

#unreg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:36
# Synonyme

# Verbindung 
[[abholen]]
[[der Freund]]
# Beispiele
- **Ich treffe meine Freunde am Wochenende.**  
    (Я встречаюсь с друзьями на выходных.)
    
- **Wir haben uns gestern getroffen.**  
    (Мы встретились вчера.)
    
- **Wen triffst du heute Abend?**  
    (С кем ты встречаешься сегодня вечером?)
    
- **Er trifft sie zum ersten Mal.**  
    (Он встречает её впервые.)
# Übersetzung
встречать, встретиться