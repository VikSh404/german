kein Plural
#nomen
# Synonyme

# Verbindung 
[[die Speise]]
# Beispiele
- **Ich esse gern Brot mit Honig.**  
    (Я люблю есть хлеб с мёдом.)
    
- **Honig ist süß und gesund.**  
    (Мёд сладкий и полезный.)
    
- **Wo steht der Honig?**  
    (Где стоит мёд?)
    
- **Sie trinkt Tee mit Honig und Zitrone.**  
    (Она пьёт чай с мёдом и лимоном.)
# Übersetzung
мёд