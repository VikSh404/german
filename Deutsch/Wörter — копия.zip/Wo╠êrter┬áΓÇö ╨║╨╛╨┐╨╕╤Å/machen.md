#reg

|Лицо|Форма|Перевод|
|---|---|---|
|ich|mache|я делаю|
|**du**|machst|ты делаешь|
|**sie (она)**|macht|она делает|
|wir|machen|мы делаем|
|ihr|macht|вы (мн.) делаете|
|sie / Sie|machen|они / Вы делаете|
# Synonyme

# Verbindung 
[[der Termin]]
[[gerade]]

# Beispiele
🔹 **Ich mache meine Hausaufgaben.**  
(Я делаю домашнее задание.)

🔹 **Was machst du gerade?**  
(Что ты сейчас делаешь?)

🔹 **Sie hat gestern viel gemacht.**  
(Она много сделала вчера.)

🔹 **Wir machten einen Spaziergang.**  
(Мы совершили прогулку.)
# Übersetzung
делать