die Städte
#nomen
# Synonyme

# Verbindung 
[[die Wohnung]]
[[die Straße]]
# Beispiele
🔹 **Ich wohne in der Stadt.**  
(Я живу в городе.)

🔹 **Die Stadt ist sehr alt.**  
(Город очень старый.)

🔹 **Viele Städte haben schöne Altstädte.**  
(У многих городов есть красивые старые части.)

🔹 **Wir fahren in die Stadt.**  
(Мы едем в город.)
# Übersetzung
город
