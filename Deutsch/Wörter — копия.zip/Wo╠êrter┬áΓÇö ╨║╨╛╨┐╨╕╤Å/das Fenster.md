die Fenster
#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 23:43
# Synonyme

# Verbindung 
[[die Wohnung]]
# Beispiele
- **Das Fenster ist offen.**  
    (Окно открыто.)
    
- **Kannst du bitte das Fenster schließen?**  
    (Ты можешь, пожалуйста, закрыть окно?)
    
- **Die Fenster sind sehr schmutzig.**  
    (Окна очень грязные.)
    
- **Ich sehe aus dem Fenster.**  
    (Я смотрю в окно.)
# Übersetzung
окно