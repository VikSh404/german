-
#nomen
# Synonyme
[[das Geld]]
# Verbindung 

# Beispiele
1. **Gibt man in Deutschland Trinkgeld?**  
    — В Германии принято давать чаевые?
    
2. **Er hat fünf Euro Trinkgeld gegeben.**  
    — Он дал пять евро чаевых.
    
3. **Das Trinkgeld ist nicht im Preis enthalten.**  
    — Чаевые не включены в цену.
    
4. **Ich habe dem Kellner ein gutes Trinkgeld hinterlassen.**  
    — Я оставил официанту хорошие чаевые.
# Übersetzung
чаевые