der Hunger
-

#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 11:43
# Synonyme

# Verbindung 
[[das Essen]]
# Beispiele
| Немецкий              | Перевод                   |
| --------------------- | ------------------------- |
| **Ich habe Hunger.**  | Я голоден.                |
| **Du hast Hunger.**   | Ты голоден.               |
| **Er hat Hunger.**    | Он голоден.               |
| **Sie hat Hunger.**   | Она голодна.              |
| **Wir haben Hunger.** | Мы голодны.               |
| **Ihr habt Hunger.**  | Вы голодны (группа).      |
| **Sie haben Hunger.** | Они голодны / Вы голодны. |

| Немецкий                    | Перевод            |
| --------------------------- | ------------------ |
| **Ich habe keinen Hunger.** | Я не голоден.      |
| **Er hatte keinen Hunger.** | Он не был голоден. |
# Übersetzung
был голодным