die Wörter
#nomen
# Synonyme

# Verbindung 
[[aufschreiben]]
# Beispiele
🔹 **Ich kenne diese Wörter nicht.**  
(Я не знаю этих слов.)

🔹 **Wie viele Wörter sind das?**  
(Сколько это слов?)

🔹 **Bitte ordne die Wörter den Bildern zu.**  
(Пожалуйста, соотнеси слова с картинками.)
# Übersetzung
слово
