#reg 
# Synonyme

# Verbindung 
[[anmachen]]
[[das Licht]]
[[der Fernseher]]
[[der Termin]]
# Beispiele
Du machst das Licht aus (Ты выключаешь свет.)
Sie hat den Fernseher ausgemacht. (Она выключила телевизор.)

🔹 **Können wir einen Termin ausmachen?**  
(Можем договориться о встрече?)
# Übersetzung
1. Bыключать
2. Договариваться
