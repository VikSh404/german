schlief, hat geschlafen
du - schläfst
sie - schläft

#unreg
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:24
# Synonyme

# Verbindung 
[[die Wohnung]]
# Beispiele
- **Ich schlafe meistens acht Stunden.**  
    — Я обычно сплю восемь часов.
    
- **Du schläfst sehr tief.**  
    — Ты спишь очень крепко.
    
- **Sie schläft schon.**  
    — Она уже спит.
    
- **Wir haben gut geschlafen.**  
    — Мы хорошо выспались.
    
- **Schläfst du noch oder bist du wach?**  
    — Ты ещё спишь или уже проснулся?
# Übersetzung
спать