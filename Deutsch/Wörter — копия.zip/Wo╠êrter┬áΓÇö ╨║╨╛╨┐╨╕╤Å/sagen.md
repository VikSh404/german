#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 23:50
# Synonyme
[[sprechen ]]
[[reden]]
# Verbindung 
[[erzählen]]
# Beispiele
- **Was hast du gesagt?**  
    (Что ты сказал?)
    
- **Er sagt die Wahrheit.**  
    (Он говорит правду.)
    
- **Ich sage dir später Bescheid.**  
    (Я скажу тебе позже.)
    
- **Sie hat nichts gesagt.**  
    (Она ничего не сказала.)
# Übersetzung
говорить, сказать