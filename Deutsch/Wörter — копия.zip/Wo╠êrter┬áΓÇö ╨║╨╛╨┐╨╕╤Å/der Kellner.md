die Kellner
#nomen
# Synonyme

# Verbindung 
[[die Kellnerin]]
[[das Trinkgeld]]
# Beispiele
1. **Der Kellner bringt die Speisekarte.**  
    — Официант приносит меню.
    
2. **Ich rufe den Kellner.**  
    — Я зову официанта.
    
3. **Die Kellnerin war sehr freundlich.**  
    — Официантка была очень дружелюбной.
    
4. **In diesem Restaurant arbeiten viele Kellner.**  
    — В этом ресторане работает много официантов.
# Übersetzung
официант