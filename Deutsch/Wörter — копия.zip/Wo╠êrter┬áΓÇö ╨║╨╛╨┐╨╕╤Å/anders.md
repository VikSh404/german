#adverb
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 13:47
# Synonyme

# Verbindung 
[[machen]]
# Beispiele
1. **Ich sehe das anders.**  
    — Я вижу это по-другому. _(= у меня другое мнение)_
    
2. **Heute ist alles anders als gestern.**  
    — Сегодня всё иначе, чем вчера.
    
3. **Machst du das anders als ich?**  
    — Ты делаешь это иначе, чем я?
    
4. **Warum benimmst du dich plötzlich so anders?**  
    — Почему ты вдруг так странно себя ведёшь? _(букв. по-другому)_
# Übersetzung
иначе, по-другому, по-иному