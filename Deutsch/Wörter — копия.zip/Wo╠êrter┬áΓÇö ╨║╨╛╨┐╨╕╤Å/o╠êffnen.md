#reg
# Synonyme

# Verbindung 
[[aufmachen]]
# Beispiele
# Übersetzung
открывать