die Tees
#nomen
# Synonyme

# Verbindung 
[[die Speise]]

- **der Kräutertee** – травяной чай
- **der Schwarztee** – чёрный чай
- **der Grüntee** – зелёный чай
- **der Früchtetee** – фруктовый чай
- **die Teekanne** – чайник
- **das Teeglas / die Teetasse** – стакан / чашка для чая
# Beispiele
- **Ich trinke gern Tee.**  
    — Я люблю пить чай.
    
- **Möchtest du einen Tee?**  
    — Хочешь чаю?
    
- **Der Tee ist noch heiß.**  
    — Чай ещё горячий.
    
- **In Deutschland trinkt man oft Kräutertee.**  
    — В Германии часто пьют травяной чай.
# Übersetzung
