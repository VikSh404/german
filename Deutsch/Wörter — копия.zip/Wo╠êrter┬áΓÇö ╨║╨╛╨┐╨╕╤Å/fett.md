#adverb
# Synonyme

# Verbindung 
[[das Fett]]
# Beispiele
- **Dieses Fleisch ist zu fett.**  
    — Это мясо слишком жирное.
    
- **Ich esse keinen fetten Käse.**  
    — Я не ем жирный сыр.
    
- **Er hat fette Fingerabdrücke auf dem Glas hinterlassen.**  
    — Он оставил жирные отпечатки пальцев на стекле.
    
- **Das war ein fetter Fehler!** _(разг.)_  
    — Это была крупная ошибка!
# Übersetzung
жирный / жир