#adverb
# Synonyme

# Verbindung 
[[fast nie]]
[[fast immer]]
# Beispiele
🔹 **Ich bin fast fertig.**  
(Я почти закончил.)

🔹 **Er hat das fast vergessen.**  
(Он **чуть не** забыл это.)

🔹 **Wir haben fast den Bus verpasst.**  
(Мы **чуть не** опоздали на автобус.)

🔹 **Fast alle Schüler waren da.**  
(**Почти все** ученики были там.)

🔹 **Sie ist fast nie krank.**  
(Она **почти никогда** не болеет.)
# Übersetzung
- **почти**
- **едва не**, **чуть не**