die Metzgereien

#nomen
# Synonyme

# Verbindung 
[[kaufen]]
# Beispiele
1. **Ich kaufe Wurst in der Metzgerei.**  
    — Я покупаю колбасу в мясной лавке.
    
2. **Die Metzgerei ist neben der Bäckerei.**  
    — Мясной магазин находится рядом с пекарней.
    
3. **In dieser Metzgerei gibt es frisches Fleisch.**  
    — В этом мясном магазине есть свежее мясо.
    
4. **Viele Metzgereien machen auch heiße Snacks.**  
    — Во многих мясных лавках также продаются горячие закуски.
# Übersetzung
мясная лавка