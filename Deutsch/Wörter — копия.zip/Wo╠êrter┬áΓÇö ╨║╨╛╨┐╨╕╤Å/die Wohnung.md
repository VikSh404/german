die Wohnungen
#nomen
# Synonyme

# Verbindung 
[[die Stadt]]
# Beispiele
🔹 **Ich habe eine neue Wohnung.**  
(У меня новая квартира.)

🔹 **Die Wohnung ist sehr hell und groß.**  
(Квартира очень светлая и большая.)

🔹 **Wir suchen eine Wohnung in der Stadt.**  
(Мы ищем квартиру в городе.)

🔹 **Die Fenster der Wohnung sind offen.**  
(Окна квартиры открыты.)
# Übersetzung
квартира