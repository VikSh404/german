#adverb
# Synonyme

# Verbindung 
[[morgens]]
[[täglich]]
# Beispiele
🔹 **Ich esse mittags immer warm.**  
(Я всегда ем тёплую еду в обед.)

🔹 **Mittags mache ich eine Pause.**  
(В обед я делаю перерыв.)

🔹 **Gehst du mittags nach Hause?**  
(Ты уходишь домой в обед?)

🔹 **Mittags ist die Sonne am höchsten.**  
(В обед солнце стоит выше всего.)
# Übersetzung
- **в обед**
- **днём**
- **по обедам / каждый день в обед**