-
#nomen
# Synonyme

# Verbindung 
[[gewinnen]]
# Beispiele
1. **Ich treibe regelmäßig Sport.**  
    — Я регулярно занимаюсь спортом.
    
2. **Sport ist gesund.**  
    — Спорт полезен для здоровья.
    
3. **Magst du Mannschaftssport oder Einzelsport?**  
    — Тебе нравится командный спорт или индивидуальный?
    
4. **Nach der Arbeit mache ich etwas Sport.**  
    — После работы я немного занимаюсь спортом.
# Übersetzung
спорт