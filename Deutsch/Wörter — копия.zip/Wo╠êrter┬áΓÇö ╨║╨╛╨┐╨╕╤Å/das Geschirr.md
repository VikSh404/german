#nomen
# Synonyme

# Verbindung 
[[der Becher]]
[[die Tasse]]
[[das Glas]]
[[die Küche]]
# Beispiele
🔹 **Das Geschirr ist schmutzig.**  
(Посуда грязная.)

🔹 **Ich muss das Geschirr spülen.**  
(Мне нужно помыть посуду.)

🔹 **Wo ist das saubere Geschirr?**  
(Где чистая посуда?)

🔹 **Er hat das Geschirr in die Spülmaschine gestellt.**  
(Он поставил посуду в посудомоечную машину.)
# Übersetzung
посуда