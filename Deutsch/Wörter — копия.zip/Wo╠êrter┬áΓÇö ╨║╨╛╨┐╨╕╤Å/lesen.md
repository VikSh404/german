las, hat gelesen
Präteritum, Perfekt
du - liest  -- Du **liest** sehr schnell.
sie - liest -- 	Sie liest ein Märchen.

#unreg
# Synonyme

# Verbindung 
[[das Buch]]


# Beispiele
🔹 Du liest ein spannendes Buch.
(Ты читаешь захватывающую книгу.)

🔹 Sie hat das Buch gestern gelesen.
(Она прочитала книгу вчера.)

🔹 Wir lesen gern auf Deutsch.
(Мы любим читать на немецком.)
# Übersetzung
читать