gewann, hat gewonnen
du - gewinnst
sie - gewinnt

#unreg
# Synonyme

# Verbindung
[[der Sport]]
# Beispiele
- **Wir gewinnen das Spiel!**  
    — Мы выигрываем игру!
    
- **Er hat im Lotto gewonnen.**  
    — Он выиграл в лотерею.
    
- **Letztes Jahr gewann sie eine Medaille.**  
    — В прошлом году она выиграла медаль.
    
- **Ich möchte mehr Erfahrung gewinnen.**  
    — Я хочу приобрести больше опыта.
# Übersetzung
выигрывать, побеждать, приобретать