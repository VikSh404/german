die Gäste
#nomen
# Synonyme

# Verbindung 
[[die Wohnung]]
# Beispiele
- **Der Gast kommt um 18 Uhr.**  
    — Гость придёт в 18 часов.
    
- **Wir haben heute viele Gäste.**  
    — У нас сегодня много гостей.
    
- **Die Gäste sitzen schon am Tisch.**  
    — Гости уже сидят за столом.
    
- **Ich war als Gast eingeladen.**  
    — Я был приглашён как гость.
# Übersetzung
гость