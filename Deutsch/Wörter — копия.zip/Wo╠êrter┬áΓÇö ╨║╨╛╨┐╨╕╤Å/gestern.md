**gestern** всегда стоит **перед глаголом** или **в начале предложения** (позиция 1 или 3)

#adverb
# Synonyme

# Verbindung 
|Наречие|Перевод|
|---|---|
|**gestern**|вчера|
|**heute**|сегодня|
|**morgen**|завтра|
|**vorgestern**|позавчера|
|**übermorgen**|послезавтра|
[[heute]]
[[morgen]]
[[vorgestern]]

# Beispiele
🔹 **Gestern war Montag.**  
(Вчера был понедельник.)

🔹 **Ich habe dich gestern gesehen.**  
(Я видел тебя вчера.)

🔹 **Gestern habe ich Deutsch gelernt.**  
(Вчера я учил немецкий.)

🔹 **Was hast du gestern gemacht?**  
(Что ты делал вчера?)
# Übersetzung
вчера