die Busse
#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 12:56
# Synonyme

# Verbindung 
[[das Auto]]
[[der Wagen]]
# Beispiele
- **Der Bus kommt in zehn Minuten.**  
    (Автобус приедет через десять минут.)
    
- **Ich fahre mit dem Bus zur Schule.**  
    (Я еду в школу на автобусе.)
    
- **Die Busse sind heute sehr voll.**  
    (Сегодня автобусы очень переполнены.)
    
- **Wo ist die nächste Bushaltestelle?**  
    (Где ближайшая автобусная остановка?)
# Übersetzung
автобус