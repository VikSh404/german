hing, hat gehangen
+Dat
#unreg 
1️ слабым (правильным) – когда что-то вешают (Akkusativ)
2️ сильным (неправильным) – когда что-то уже висит (Dativ)
# Synonyme

# Verbindung 
[[hängen (Akk)]]
[[das Bild]]
# Beispiele
🔹 **Sie hängt an der Wand.**  
(Она висит на стене.)
🔹 **Das Bild hängt an der Wand.**  
(Картина висит на стене.) → Dativ, сильный глагол
# Übersetzung
висеть