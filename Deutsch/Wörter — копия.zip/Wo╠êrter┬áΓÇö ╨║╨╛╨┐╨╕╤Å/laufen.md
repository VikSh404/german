lief, ist gelaufen
du - läufst
sie - läuft

#unreg
# Synonyme
[[gehen]]
# Verbindung 

# Beispiele

# Übersetzung