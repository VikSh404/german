kein Plural
#nomen
# Synonyme

# Verbindung 
[[verdienen]]
# Beispiele
🔹 **Ich habe großen Respekt vor dir.**  
(Я очень уважаю тебя.)  
→ **vor + Dativ**: **vor dir**

🔹 **Kinder sollen Respekt vor den Lehrern haben.**  
(Дети должны уважать учителей.)

🔹 **Er hat ihren Mut mit Respekt betrachtet.**  
(Он с уважением смотрел на её мужество.)

🔹 **Sie verdient Respekt.**  
(Она заслуживает уважения.)
# Übersetzung
уважение