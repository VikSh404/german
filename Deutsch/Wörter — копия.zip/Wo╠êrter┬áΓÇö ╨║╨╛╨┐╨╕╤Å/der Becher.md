der Becher
#nomen
# Synonyme
[[die Tasse]]
[[das Glas]]
[[das Geschirr]]
# Verbindung 


# Beispiele

🔹 **Ich trinke einen Kaffee aus dem Becher.**  
(Я пью кофе из стаканчика.)

🔹 **Hast du einen Plastikbecher?**  
(У тебя есть пластиковый стакан?)

🔹 **Sie isst einen Joghurt aus dem Becher.**  
(Она ест йогурт из стаканчика.)

🔹 **Bitte wirf den Becher in den Müll.**  
(Пожалуйста, выброси стакан в мусор.)
# Übersetzung
- **стакан** (обычно пластиковый, бумажный или для йогурта)
- **кружка без ручки**
- **чашка (спортивный кубок – реже)**