die Tage
#nomen
# Synonyme

# Verbindung 
[[die Woche]]
[[täglich]]
[[werktags]]
# Beispiele
🔹 **Der Tag ist schön.**  
(День прекрасный.)

🔹 **Ich habe den ganzen Tag gearbeitet.**  
(Я работал весь день.)

🔹 **Wir sehen uns in ein paar Tagen.**  
(Увидимся через несколько дней.)

🔹 **Am Tag ist es warm, aber in der Nacht kalt.**  
(Днём тепло, но ночью холодно.)
# Übersetzung
день