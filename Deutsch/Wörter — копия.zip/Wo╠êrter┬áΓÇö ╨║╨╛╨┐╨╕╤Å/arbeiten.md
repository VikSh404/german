часто с **bei + Dativ** (работать где-то) или **an + Dativ** (над чем-то)
#reg
# Synonyme

# Verbindung 
[[verdienen]]
[[das Geld]]
[[der Bus]]
# Beispiele
#### ✅ Präsens:

🔹 **Ich arbeite bei Siemens.**  
(Я работаю в Siemens.)

🔹 **Du arbeitest zu viel!**  
(Ты слишком много работаешь!)

#### ✅ Präteritum:

🔹 **Sie arbeitete gestern bis spät.**  
(Она работала вчера допоздна.)

#### ✅ Perfekt:

🔹 **Wir haben den ganzen Tag gearbeitet.**  
(Мы работали весь день.)
# Übersetzung
работать