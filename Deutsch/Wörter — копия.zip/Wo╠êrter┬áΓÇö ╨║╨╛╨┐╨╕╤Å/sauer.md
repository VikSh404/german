#adverb
# Synonyme

# Verbindung 

[[salzig]]

die Säure – кислота

die Milchsäure – молочная кислота

sauer werden – прокиснуть (о продуктах)

sauer sein auf + Akk. – злиться на кого-то

sauer reagieren – сердито отреагировать


# Beispiele
- **Die Zitrone ist sehr sauer.**  
    — Лимон очень кислый.
    
- **Ich mag kein saures Gemüse.**  
    — Я не люблю кислые овощи.
    
- **Der Apfel schmeckt sauer.**  
    — Яблоко на вкус кислое.


- **Warum bist du so sauer?**  
    — Почему ты такой сердитый?
    
- **Er war sauer auf mich.**  
    — Он злился на меня.
# Übersetzung
кислый, сердитый