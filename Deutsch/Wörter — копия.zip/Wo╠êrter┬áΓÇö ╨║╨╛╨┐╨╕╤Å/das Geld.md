kein Plural
#nomen
# Synonyme

# Verbindung 
[[behalten]]

# Beispiele
🔹 **Ich habe kein Geld.**  
(У меня нет денег.)

🔹 **Er verdient viel Geld.**  
(Он зарабатывает много денег.)

🔹 **Sie gibt dem Kind Geld.**  
(Она даёт ребёнку деньги.)

🔹 **Die Farbe des Geldes ist grün.**  
(Цвет денег — зелёный.) – пример с Genitiv

# Übersetzung
