die Spülmaschinen
#nomen
# Synonyme
[[der Geschirrspüler]]
# Verbindung 
[[das Geschirr]]
# Beispiele
- **Unsere Spülmaschine ist kaputt.**  
    — Наша посудомоечная машина сломалась.
    
- **Ich räume die Spülmaschine ein.**  
    — Я загружаю посудомойку.
    
- **Kannst du bitte die Spülmaschine ausräumen?**  
    — Можешь, пожалуйста, выгрузить посуду из машины?
    
- **In der neuen Küche steht eine moderne Spülmaschine.**  
    — В новой кухне стоит современная посудомоечная машина.
# Übersetzung
посудомоечная машина