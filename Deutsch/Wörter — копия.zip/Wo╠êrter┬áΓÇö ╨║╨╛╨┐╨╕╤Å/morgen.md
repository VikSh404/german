

#adverb
# Synonyme

# Verbindung 
| Наречие        | Перевод     |
| -------------- | ----------- |
| **gestern**    | вчера       |
| **heute**      | сегодня     |
| **morgen**     | завтра      |
| **vorgestern** | позавчера   |
| **übermorgen** | послезавтра |
|                |             |
[[gestern]]
[[heute]]
[[übermorgen]]
# Beispiele
- **Ich schreibe dir morgen.**  
    (Я напишу тебе **завтра**.)
    
- **Morgen ist Freitag.**  
    (**Завтра** пятница.)
    
- **Wir fliegen morgen nach Berlin.**  
    (Мы летим **завтра** в Берлин.)
# Übersetzung
завтра
