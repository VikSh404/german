#reg
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:44
# Synonyme

# Verbindung 
[[wirklich]]
[[eigentlich]]
# Beispiele
- **Wir reden über das Wetter.**  
    — Мы говорим о погоде.
    
- **Mit dir kann man gut reden.**  
    — С тобой приятно поговорить.
    
- **Redet ihr noch miteinander?**  
    — Вы ещё разговариваете друг с другом?
    
- **Er hat viel Unsinn geredet.**  
    — Он наговорил много ерунды.
    
- **Ich will nicht darüber reden.**  
    — Я не хочу об этом говорить.
# Übersetzung
разговаривать, беседовать, говорить