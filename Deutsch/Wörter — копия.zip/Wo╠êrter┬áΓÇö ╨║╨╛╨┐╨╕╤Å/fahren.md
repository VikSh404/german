fuhr, ist gefahren
du - fährst
sie - fährt

#unreg
# Synonyme

# Verbindung 
[[gehen]]
# Beispiele
# Übersetzung
ехать

