#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:13
# Synonyme

# Verbindung 
[[der Fernseher]]
# Beispiele
- **Warum benimmst du dich so komisch?**  
    — Почему ты так странно себя ведёшь?
    
- **Ich habe einen komischen Traum gehabt.**  
    — Мне приснился странный сон.
    
- **Der Clown war echt komisch.**  
    — Клоун был действительно смешной.
    
- **Etwas ist komisch an dieser Geschichte.**  
    — Что-то странное в этой истории.
# Übersetzung
странный, смешной