#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:16
# Synonyme

# Verbindung 
[[fett]]
[[das Essen]]

# Beispiele
1. **Ich bin satt.**  
    — Я сыт.
    
2. **Bist du schon satt?**  
    — Ты уже наелся?
    
3. **Nach dem Abendessen war ich richtig satt.**  
    — После ужина я был действительно сыт.
    
4. **Der Hund ist satt und schläft.**  
    — Собака сыта и спит.
# Übersetzung
сытый
