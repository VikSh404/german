die Empfänge

#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 14:10
# Synonyme
[[das Krankenhaus]]
[[das Hotel]]

# Verbindung 

# Beispiele
- **Der Empfang im Hotel ist rund um die Uhr besetzt.**  
    (Ресепшн в отеле работает круглосуточно.)
    
- **Ich habe keinen Empfang auf dem Handy.**  
    (У меня нет сигнала на телефоне.)
    
- **Der Präsident gab einen Empfang für die Gäste.**  
    (Президент устроил приём для гостей.)
    
- **Bitte melden Sie sich am Empfang.**  
    (Пожалуйста, обратитесь на ресепшн.)
# Übersetzung
приём (гостей, сигнала, людей)
ресепшн / стойка регистрации
сигнал (мобильный, телевизионный)