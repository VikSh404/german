#reg
# Synonyme

# Verbindung 
[[sich merken]]

# Beispiele
🔹 **Ich merke, dass du müde bist.**  
(Я замечаю, что ты устал.)

🔹 **Hast du etwas gemerkt?**  
(Ты что-нибудь заметил?)
# Übersetzung
замечать