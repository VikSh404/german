die Sendungen
#nomen
# Synonyme

# Verbindung 
[[der Fernseher]]
[[das Fernsehen]]
# Beispiele
### **1. Передача (TV / Radio)**

- **Die Sendung beginnt um 20 Uhr.**  
    — Передача начинается в 20:00.
    
- **Das war eine interessante Sendung über Tiere.**  
    — Это была интересная передача о животных.
    
- **Hast du die Sendung gestern gesehen?**  
    — Ты смотрел вчерашнюю передачу?
    

---

### ✅ **2. Посылка / отправление**

- **Ich warte auf eine Sendung aus Deutschland.**  
    — Я жду посылку из Германии.
    
- **Ihre Sendung wurde verschickt.**  
    — Ваша посылка была отправлена.
    
- **Die Sendung ist noch unterwegs.**  
    — Посылка ещё в пути.
# Übersetzung
- **передача** (по телевидению или радио)
    
- **посылка, отправление**