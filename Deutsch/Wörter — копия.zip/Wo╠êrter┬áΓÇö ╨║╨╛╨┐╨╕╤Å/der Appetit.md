kein Plural
#nomen
# Synonyme

# Verbindung 
[[die Speise]]
[[das Gericht]]
# Beispiele
- **Ich habe heute keinen Appetit.**  
    (У меня сегодня нет аппетита.)
    
- **Guten Appetit!**  
    (Приятного аппетита!)
    
- **Sie hat großen Appetit auf Pizza.**  
    (У неё большой аппетит к пицце.)
    
- **Nach dem Sport kommt der Appetit.**  
    (После спорта приходит аппетит.)
# Übersetzung
аппетит