schloss, geschlossen

#unreg 
# Synonyme:
[[zumachen]]
# Verbindung 

# Beispiele
# Übersetzung 
закрывать