#adverb
# Synonyme

# Verbindung 
[[süß]]
# Beispiele
#### ✅ В значении «острый» (о еде):

1. **Das Curry ist sehr scharf.**  
    — Карри очень острый.
    
2. **Magst du scharfes Essen?**  
    — Ты любишь острую еду?
    

#### 🔪 В значении «острый» (о ножах и т.п.):

3. **Das Messer ist scharf.**  
    — Нож острый.
    
4. **Sei vorsichtig, die Klinge ist sehr scharf!**  
    — Осторожно, лезвие очень острое!
    

#### 🧠 В переносных значениях:

5. **Ein scharfes Bild.**  
    — Чёткое изображение.
    
6. **Sie hat einen scharfen Verstand.**  
    — У неё острый ум.
    
7. _(разг.)_ **Die sieht aber scharf aus!**  
    — Она выглядит очень сексуально! 🙈
# Übersetzung
острый, резкий, отчётливый, сексуальный