die Badezimmer

#nomen
# Synonyme

# Verbindung 
[[die Wohnung]]
# Beispiele
1. **Das Badezimmer ist im ersten Stock.**  
    — Ванная комната находится на втором этаже.
    
2. **Ich putze heute das Badezimmer.**  
    — Сегодня я убираю ванную.
    
3. **Das neue Badezimmer hat eine große Dusche.**  
    — В новой ванной — большая душевая кабина.
    
4. **Wo ist das Bad?** _(разг.)_  
    — Где ванная?
# Übersetzung
ванная комната