#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:18
# Synonyme
[[komisch]]
# Verbindung 

# Beispiele
- **Das ist ein seltsames Geräusch.**  
    — Это странный звук.
    
- **Ich hatte ein seltsames Gefühl.**  
    — У меня было странное чувство.
    
- **Er benimmt sich heute sehr seltsam.**  
    — Он сегодня ведёт себя очень странно.
    
- **Das kommt mir seltsam vor.**  
    — Это мне кажется подозрительным.
# Übersetzung
странный, необычный, чудной, подозрительный