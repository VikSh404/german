sprach, hat gesprochen
du - sprichst
sie - spricht

#unreg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:00
# Synonyme
[[reden]]
[[der Mensch]]
# Verbindung 

# Beispiele
- **Ich spreche Deutsch und Englisch.**  
    (Я говорю по-немецки и по-английски.)
    
- **Mit wem sprichst du?**  
    (С кем ты разговариваешь?)
    
- **Wir haben über das Problem gesprochen.**  
    (Мы поговорили о проблеме.)
    
- **Er spricht sehr leise.**  
    (Он говорит очень тихо.)
# Übersetzung
говорить, разговаривать