#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:23
# Synonyme

# Verbindung 
[[schlafen]]
# Beispiele
1. **Ich bin noch nicht richtig wach.**  
    — Я ещё не совсем проснулся.
    
2. **Bist du schon wach?**  
    — Ты уже проснулся?
    
3. **Er hat einen wachen Verstand.**  
    — У него острый/живой ум.
    
4. **Die Kinder waren um 6 Uhr schon wach.**  
    — Дети уже были бодрыми в 6 утра.
# Übersetzung
бодрый, проснувшийся, не спящий, настороженный