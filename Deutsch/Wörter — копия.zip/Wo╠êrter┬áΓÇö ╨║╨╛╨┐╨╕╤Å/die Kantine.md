die Kantinen

#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 12:32
# Synonyme

# Verbindung 
[[essen]]                        
# Beispiele
- **Wir essen mittags in der Kantine.**  
    (Мы обедаем в столовой.)
    
- **Die Kantine ist von 11 bis 14 Uhr geöffnet.**  
    (Столовая открыта с 11 до 14 часов.)
    
- **In der Kantine gibt es heute Fisch.**  
    (Сегодня в столовой рыба.)
    
- **Die Preise in der Kantine sind günstig.**  
    (Цены в столовой выгодные.)
# Übersetzung
столовая