#adverb
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:39
# Synonyme
[[wirklich]]
[[eigentlich]]
# Verbindung 

# Beispiele
|Немецкий|Русский|
|---|---|
|**Du hast Recht.**|Ты прав.|
|**Ich habe Recht gehabt.**|Я был прав.|
|**Er hat nicht ganz Recht.**|Он не совсем прав.|
|**Hab ich Recht oder nicht?**|Я прав или нет?|
|**Sie hatte völlig Recht.**|Она была абсолютно права.|
# Übersetzung
быть правым