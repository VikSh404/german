#reg 
# Synonyme:
[[schließen]]
# Verbindung 

# Beispiele
# Übersetzung 
закрывать