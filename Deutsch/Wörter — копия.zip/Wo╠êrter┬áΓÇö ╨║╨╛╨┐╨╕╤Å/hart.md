#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:10
# Synonyme

# Verbindung 
[[arbeiten]]
[[schwierig ]]
# Beispiele
1. **Das Bett ist zu hart.**  
    — Кровать слишком жёсткая.
    
2. **Sie arbeitet hart.** _(наречие)_  
    — Она тяжело работает.
    
3. **Du bist zu hart zu dir selbst.**  
    — Ты слишком строг к себе.
    
4. **Nach einem harten Winter kommt ein schöner Frühling.**  
    — После суровой зимы приходит красивая весна.
# Übersetzung
твёрдый, жёсткий, трудный