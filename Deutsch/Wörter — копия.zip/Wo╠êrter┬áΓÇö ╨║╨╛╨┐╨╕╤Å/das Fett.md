die Fette
#nomen
# Synonyme

# Verbindung 

# Beispiele
- **Zu viel Fett ist ungesund.**  
    — Слишком много жира вредно для здоровья.
    
- **Butter enthält viel Fett.**  
    — Масло содержит много жира.
# Übersetzung
жир