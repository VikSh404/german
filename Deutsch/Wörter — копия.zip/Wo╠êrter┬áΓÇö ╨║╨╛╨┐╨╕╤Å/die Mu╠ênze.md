die Münzen
#nomen
# Synonyme

# Verbindung 
[[das Geld]]
[[bar]]
# Beispiele
- **Ich sammle alte Münzen.**  
    — Я собираю старые монеты.
    
- **Hast du eine 2-Euro-Münze?**  
    — У тебя есть монета в 2 евро?
    
- **Die Münzen sind in meiner Tasche.**  
    — Монеты у меня в кармане.
    
- **In der Kasse fehlen zwei Münzen.**  
    — В кассе не хватает двух монет.
# Übersetzung
монета