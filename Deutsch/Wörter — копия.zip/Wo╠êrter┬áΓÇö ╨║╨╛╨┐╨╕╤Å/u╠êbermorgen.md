

#adverb
# Synonyme

# Verbindung 
| Наречие        | Перевод     |
| -------------- | ----------- |
| **gestern**    | вчера       |
| **heute**      | сегодня     |
| **morgen**     | завтра      |
| **vorgestern** | позавчера   |
| **übermorgen** | послезавтра |
|                |             |
[[gestern]]
[[heute]]
[[die Zeit]]
# Beispiele
🔹 **Ich schreibe die Prüfung übermorgen.**  
(Я пишу экзамен **послезавтра**.)

🔹 **Übermorgen fahren wir in den Urlaub.**  
(**Послезавтра** мы едем в отпуск.)

🔹 **Heute ist Dienstag, also ist übermorgen Donnerstag.**  
(Сегодня вторник, значит **послезавтра** четверг.)
# Übersetzung
послезавтра
