behielt - hat behalten
du - behältst
sie - behält

#unreg
# Synonyme

# Verbindung 
[[die Wohnung]]

# Beispiele
🔹 **Du behältst das Geld.**  
(Ты оставляешь деньги себе.)

🔹 **Sie behält den Überblick.**  
(Она сохраняет контроль / общее представление.)

🔹 **Ich behalte mir das Recht vor.**  
(Я оставляю за собой право.)
# Übersetzung
сохранять, оставлять (у себя)