#adverb
# Synonyme

# Verbindung 

# Beispiele
🔹 **Ich gehe selten ins Kino.**  
(Я редко хожу в кино.)

🔹 **Er ist selten krank.**  
(Он редко болеет.)

🔹 **Wir sehen uns leider nur selten.**  
(К сожалению, мы видимся лишь изредка.)

🔹 **So etwas sieht man selten.**  
(Такое увидишь нечасто.)
# Übersetzung
редко