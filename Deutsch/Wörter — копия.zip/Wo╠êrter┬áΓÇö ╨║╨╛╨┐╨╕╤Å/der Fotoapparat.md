die Fotoapparate
#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:15
# Synonyme
[[die Kamera]]
# Verbindung 
[[das Bild]]
[[das Museum]]
# Beispiele
- **Der Fotoapparat ist teuer.**  
    (Фотоаппарат дорогой.)
    
- **Ich habe meinen Fotoapparat vergessen.**  
    (Я забыл свой фотоаппарат.)
    
- **Er macht Fotos mit einem alten Fotoapparat.**  
    (Он фотографирует на старый фотоаппарат.)
    
- **Verkaufst du deinen Fotoapparat?**  
    (Ты продаёшь свой фотоаппарат?)
# Übersetzung
фотоаппарат