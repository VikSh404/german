#reg
# Synonyme
[[öffnen]]
# Verbindung 
[[zumachen]]
# Beispiele
# Übersetzung
открывать
