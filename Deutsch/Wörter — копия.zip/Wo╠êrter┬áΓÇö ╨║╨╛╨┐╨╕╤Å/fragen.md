#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:34
# Synonyme

# Verbindung 
[[reden]]
[[sprechen]]
# Beispiele
- **Ich frage den Lehrer.**  
    (Я спрашиваю учителя.)
    
- **Er hat mich etwas gefragt.**  
    (Он меня кое-что спросил.)
    
- **Sie fragt: „Wie spät ist es?“**  
    (Она спрашивает: «Сколько времени?»)
    
- **Kann ich dich etwas fragen?**  
    (Можно тебя кое-что спросить?)
# Übersetzung
спрашивать