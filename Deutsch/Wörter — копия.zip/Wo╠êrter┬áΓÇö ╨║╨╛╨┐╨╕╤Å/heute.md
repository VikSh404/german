**heute** всегда стоит **перед глаголом** или **в начале предложения** (позиция 1 или 3)

#adverb
# Synonyme

# Verbindung 
| Наречие        | Перевод     |
| -------------- | ----------- |
| **gestern**    | вчера       |
| **heute**      | сегодня     |
| **morgen**     | завтра      |
| **vorgestern** | позавчера   |
| **übermorgen** | послезавтра |
|                |             |
[[gestern]]
[[morgen]]
[[die Zeit]]
# Beispiele
🔹 **Heute ist Montag.**  
(Сегодня понедельник.)

🔹 **Ich habe heute keine Zeit.**  
(У меня сегодня нет времени.)

🔹 **Was machst du heute?**  
(Что ты делаешь сегодня?)

🔹 **Heute Abend gehe ich ins Kino.**  
(Сегодня вечером я иду в кино.)
# Übersetzung
сегодня
