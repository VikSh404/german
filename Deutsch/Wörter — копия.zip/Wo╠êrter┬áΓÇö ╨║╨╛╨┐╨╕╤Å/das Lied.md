die Lieder
#nomen
# Synonyme

# Verbindung 

# Beispiele
- **Ich höre gern Lieder auf Deutsch.**  
    — Я люблю слушать песни на немецком.
    
- **Das ist mein Lieblingslied.**  
    — Это моя любимая песня.
    
- **Die Kinder singen ein Lied.**  
    — Дети поют песню.
    
- **Kennst du dieses Lied?**  
    — Ты знаешь эту песню?
# Übersetzung
песня