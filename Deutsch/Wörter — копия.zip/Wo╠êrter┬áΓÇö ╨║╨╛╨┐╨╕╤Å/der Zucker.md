#nomen
# Synonyme

# Verbindung 
[[süß]]
# Beispiele
- **Der Zucker ist im Schrank.**  
    — Сахар в шкафу.
    
- **Ich nehme keinen Zucker im Tee.**  
    — Я не беру сахар в чай / я пью чай без сахара.
    
- **Kannst du mir den Zucker geben?**  
    — Можешь передать мне сахар?
    
- **Zu viel Zucker ist ungesund.**  
    — Слишком много сахара вредно для здоровья.
# Übersetzung
сахар