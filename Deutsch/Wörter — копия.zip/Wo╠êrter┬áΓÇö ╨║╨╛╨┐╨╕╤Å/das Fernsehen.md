#nomen
# Synonyme

# Verbindung 
[[fernsehen]]
[[der Fernseher]]
# Beispiele
- **Ich schaue selten Fernsehen.**  
    (Я редко смотрю телевизор.)
    
- **Das Fernsehen zeigt heute einen guten Film.**  
    (По телевидению сегодня показывают хороший фильм.)
# Übersetzung
телевидение