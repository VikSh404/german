#adverb
# Synonyme

# Verbindung 
[[immer]]
[[fast nie]]
# Beispiele
🔹 **Ich rauche nie.**  
(Я **никогда** не курю.)

🔹 **Er kommt nie zu spät.**  
(Он **никогда** не опаздывает.)

🔹 **Warum lernst du nie für die Prüfungen?**  
(Почему ты **никогда** не готовишься к экзаменам?)

🔹 **Sie hat ihn nie gesehen.**  
(Она **никогда** его не видела.)
# Übersetzung
никогда