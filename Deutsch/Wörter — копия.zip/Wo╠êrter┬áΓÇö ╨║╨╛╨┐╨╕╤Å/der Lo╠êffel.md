die Löffel
#nomen
# Synonyme

# Verbindung 
[[das Geschirr]]
[[die Gabel]]

# Beispiele
🔹 **Ich brauche einen Löffel.**  
(Мне нужна ложка.)

🔹 **Der Löffel liegt auf dem Tisch.**  
(Ложка лежит на столе.)

🔹 **Hast du noch einen Löffel?**  
(У тебя есть ещё одна ложка?)

🔹 **Er isst Suppe mit einem Löffel.**  
(Он ест суп ложкой.)
# Übersetzung
ложка