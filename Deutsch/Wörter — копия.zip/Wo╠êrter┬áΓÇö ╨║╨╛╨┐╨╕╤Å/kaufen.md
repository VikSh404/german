+Akk
#reg
# Synonyme

# Verbindung 
[[der Fernseher]]
[[das Geld]]
[[das Geschäft]]
[[der Laden]]

# Beispiele
#### ✅ Präsens:

🔹 **Ich kaufe Brot.**  
(Я покупаю хлеб.)

🔹 **Kaufst du das neue Handy?**  
(Ты покупаешь новый телефон?)

#### ✅ Präteritum:

🔹 **Er kaufte ein Auto.**  
(Он купил машину.)

#### ✅ Perfekt:

🔹 **Wir haben viele Bücher gekauft.**  
(Мы купили много книг.)

# Übersetzung
покупать
