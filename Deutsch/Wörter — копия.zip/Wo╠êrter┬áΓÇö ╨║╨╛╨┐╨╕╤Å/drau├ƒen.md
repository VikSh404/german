#adverb
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 13:57
# Synonyme

# Verbindung 
[[die Straße]]
# Beispiele
1. **Die Kinder spielen draußen.**  
    — Дети играют на улице.
    
2. **Es ist kalt draußen.**  
    — На улице холодно.
    
3. **Möchtest du draußen sitzen?**  
    — Хочешь посидеть на улице?
    
4. **Ich war den ganzen Tag draußen.**  
    — Я был весь день на улице.
# Übersetzung
снаружи, на улице, вне помещения