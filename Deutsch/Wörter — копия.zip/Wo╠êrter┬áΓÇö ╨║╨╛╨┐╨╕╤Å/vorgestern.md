

#adverb
# Synonyme

# Verbindung 
| Наречие        | Перевод     |
| -------------- | ----------- |
| **gestern**    | вчера       |
| **heute**      | сегодня     |
| **morgen**     | завтра      |
| **vorgestern** | позавчера   |
| **übermorgen** | послезавтра |
|                |             |
[[gestern]]

# Beispiele
🔹 **Ich habe ihn vorgestern getroffen.**  
(Я встретил его **позавчера**.)

🔹 **Vorgestern war das Wetter besser.**  
(**Позавчера** погода была лучше.)

🔹 **Was hast du vorgestern gemacht?**  
(Что ты делал **позавчера**?)
# Übersetzung
позавчера
