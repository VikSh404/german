#adverb
# Synonyme

# Verbindung 
[[das Geld]]
# Beispiele
- **Kann ich hier bar bezahlen?**  
    — Могу я здесь заплатить наличными?
    
- **Ich habe kein Bargeld, nur Karte.**  
    — У меня нет наличных, только карта.
    
- **Das kostet 10 Euro bar.**  
    — Это стоит 10 евро наличными.
# Übersetzung
наличными, наличный