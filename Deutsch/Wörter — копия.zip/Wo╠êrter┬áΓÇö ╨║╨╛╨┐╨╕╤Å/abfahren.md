fuhr ab, ist abgefahren
du - fährst ab
sie - fährt ab

#unreg
# Synonyme

# Verbindung 
[[gehen]]

# Beispiele
Der Zug fährt um 18 Uhr ab
Wann fährt der Bus ab?
Der nächste Zug nach Berlin fährt gleich ab.
# Übersetzung
ехать