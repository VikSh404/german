#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 12:05
# Synonyme
[[anmachen]]
# Verbindung 
[[die Fernbedienung]]
[[ausschalten]]

# Beispiele
1. **Kannst du bitte das Licht einschalten?**  
    — Можешь включить свет?
    
2. **Ich habe den Computer eingeschaltet.**  
    — Я включил компьютер.
    
3. **Er schaltet jeden Morgen das Radio ein.**  
    — Он включает радио каждое утро.
    
4. **Vergiss nicht, den Herd einzuschalten!**  
    — Не забудь включить плиту!
# Übersetzung
включать
