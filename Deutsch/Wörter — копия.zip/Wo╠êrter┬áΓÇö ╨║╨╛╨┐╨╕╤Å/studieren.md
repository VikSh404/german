#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:50
# Synonyme

# Verbindung 
[[lernen]]
# Beispiele
- **Er studiert Medizin.**  
    (Он учится на медицинском.)
    
- **Ich studiere an der Universität Wien.**  
    (Я учусь в Венском университете.)
# Übersetzung
учиться в вузе (университете)