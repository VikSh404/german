#adverb
# Synonyme
[[fast nie]]
# Verbindung 

# Beispiele
🔹 **Ich esse fast nie Fleisch.**  
(Я почти никогда не ем мясо.)

🔹 **Er ist fast nie zu Hause.**  
(Он почти никогда не бывает дома.)

🔹 **Wir sehen uns fast nie.**  
(Мы почти никогда не видимся.)

🔹 **Sie ist fast nie krank.**  
(Она почти никогда не болеет.)
# Übersetzung
почти никогда