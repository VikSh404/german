#Adjektiv
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 14:19
# Synonyme
[[komisch]]
[[witzig]]
[[der Witz]]
# Verbindung 

# Beispiele
1. **Ich finde den Film sehr lustig.**  
    — Я нахожу этот фильм очень смешным.
    
2. **Er ist ein lustiger Typ.**  
    — Он весёлый парень.
    
3. **Wir hatten gestern einen lustigen Abend.**  
    — Вчера у нас был весёлый вечер.
    
4. **Warum lachst du? War das lustig?**  
    — Почему ты смеёшься? Это было смешно?
# Übersetzung
