#reg 
# Synonyme

# Verbindung 
[[ausmachen]]
[[das Licht]]
[[der Fernseher]]
[[zumachen]]
# Beispiele
1. **Mach bitte den Fernseher an.**  
    — Включи, пожалуйста, телевизор.
    
2. **Er hat das Licht angemacht.**  
    — Он включил свет.
    
3. **Kannst du die Heizung anmachen?**  
    — Можешь включить отопление?
# Übersetzung
Включать