die Kannen
#nomen
# Synonyme

# Verbindung 

# Beispiele
🔹 **Ich habe eine Kanne Tee gemacht.**  
(Я заварил чайник чая.)

🔹 **Die Kanne steht auf dem Tisch.**  
(Чайник стоит на столе.)

🔹 **Kannst du mir die Kanne geben?**  
(Можешь дать мне чайник?)

🔹 **Wir brauchen zwei Kannen Kaffee.**  
(Нам нужно два чайника кофе.)
# Übersetzung
- **чайник** (для чая, кофе — с носиком и ручкой)
- **кувшин**
- **термос-чайник** (в зависимости от формы)