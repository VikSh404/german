die Kaffees
#nomen
# Synonyme

# Verbindung 
[[der Tee]]
# Beispiele
- **Ich trinke morgens immer Kaffee.**  
    — Я всегда пью кофе по утрам.
    
- **Möchtest du einen Kaffee?**  
    — Хочешь кофе?
    
- **Der Kaffee ist stark und heiß.**  
    — Кофе крепкий и горячий.
    
- **Er hat drei verschiedene Kaffees probiert.**  
    — Он попробовал три разных сорта кофе.
# Übersetzung
кофе