aß, hat gegessen
du - isst
sie - **isst**

#unreg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 12:25
# Synonyme

# Verbindung 
[[das Essen]]
[[Hunger haben]]
# Beispiele
- **Ich esse gern Pasta.**  
    (Я люблю есть пасту.)
    
- **Was isst du zum Frühstück?**  
    (Что ты ешь на завтрак?)
    
- **Gestern aß er eine Pizza.**  
    (Вчера он съел пиццу.)
    
- **Wir haben schon gegessen.**  
    (Мы уже поели.)
# Übersetzung
есть, кушать