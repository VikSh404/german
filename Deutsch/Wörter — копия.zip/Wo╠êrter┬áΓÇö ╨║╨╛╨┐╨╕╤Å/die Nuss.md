die Nüsse
#nomen
# Synonyme

# Verbindung 
[[die Speise]]

- **die Walnuss** – грецкий орех
- **die Haselnuss** – лесной орех
- **die Erdnuss** – арахис
- **die Kokosnuss** – кокос
- **nussfrei** – без орехов
# Beispiele
- **Ich esse gern Nüsse.**  
    — Я люблю есть орехи.
    
- **Die Nuss ist hart.**  
    — Орех твёрдый.
    
- **Hast du eine Nussallergie?**  
    — У тебя аллергия на орехи?
    
- **Er hat eine Walnuss geknackt.**  
    — Он расколол грецкий орех.
# Übersetzung
орех