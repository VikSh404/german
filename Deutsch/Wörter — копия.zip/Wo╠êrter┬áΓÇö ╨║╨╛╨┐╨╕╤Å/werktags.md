#adverb
# Synonyme

# Verbindung 
[[arbeiten]]
[[die Woche]]
# Beispiele
🔹 **Die Post ist werktags von 8 bis 18 Uhr geöffnet.**  
(Почта работает по будням с 8 до 18 часов.)

🔹 **Ich stehe werktags um 6 Uhr auf.**  
(Я встаю в 6 утра по будням.)

🔹 **Werktags habe ich keine Zeit, nur am Wochenende.**  
(В будние дни у меня нет времени, только на выходных.)
# Übersetzung
- **в будние дни**
- **по рабочим дням**