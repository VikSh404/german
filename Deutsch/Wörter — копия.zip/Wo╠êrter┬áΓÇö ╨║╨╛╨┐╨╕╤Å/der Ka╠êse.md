die Käse
#nomen
# Synonyme
[[die Speise]]
[[die Art]]
# Verbindung 

# Beispiele
- **Ich esse gern Käse.**  
    — Я люблю есть сыр.
    
- **Der Käse riecht stark.**  
    — Сыр сильно пахнет.
    
- **Welchen Käse möchtest du?**  
    — Какой сыр ты хочешь?
    
- **In Frankreich gibt es viele Käse.**  
    — Во Франции много сортов сыра.
# Übersetzung
сыр