ging, ist gegangen

#unreg
# Synonyme
[[laufen]]

# Verbindung 

# Beispiele

# Übersetzung