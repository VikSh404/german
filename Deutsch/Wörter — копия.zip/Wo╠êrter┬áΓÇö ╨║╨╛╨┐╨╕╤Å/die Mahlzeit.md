die Mahlzeiten
**„Mahlzeit!“** — как «Приятного аппетита!» или «Добрый обед!» (в рабочей среде).
#nomen
# Synonyme

# Verbindung 
[[das Gericht]]
[[die Speise]]
# Beispiele
- **Frühstück ist die wichtigste Mahlzeit des Tages.**  
    (Завтрак — самый важный приём пищи дня.)
    
- **Ich esse drei Mahlzeiten am Tag.**  
    (Я ем три раза в день.)
    
- **Zwischen den Mahlzeiten sollte man nichts naschen.**  
    (Между приёмами пищи не стоит перекусывать.)
    
- **Die Mahlzeiten im Hotel sind inklusive.**  
    (Питание в отеле включено.)
# Übersetzung
приём пищи
**„Mahlzeit!“** — как «Приятного аппетита!» или «Добрый обед!» (в рабочей среде).