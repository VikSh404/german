-
🔹 Очень **разговорное** слово  
🔹 Часто используется эмоционально, с недоверием или раздражением

#nomen
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:04
# Synonyme
[[der Unsinn]]
[[reden]]
[[sprechen]]
# Verbindung 

# Beispiele
- **Was für ein Quatsch!**  
    (Что за ерунда!)
    
- **Er redet nur Quatsch.**  
    (Он несёт одну чушь.)
    
- **Das ist doch Quatsch!**  
    (Да это же бред!)
    
- **Glaub diesen Quatsch nicht.**  
    (Не верь в эту чепуху.)
# Übersetzung
чепуха, ерунда, бред, фигня