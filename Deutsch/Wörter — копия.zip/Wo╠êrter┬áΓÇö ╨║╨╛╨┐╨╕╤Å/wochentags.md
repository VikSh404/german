#adverb
# Synonyme
[[werktags]]
# Verbindung 
[[mittags]]
[[täglich]]
[[wochentags]]
# Beispiele
- **Ich stehe wochentags um 7 Uhr auf.**  
    (Я встаю в 7 утра по будням.)
    
- **Wochentags ist viel Verkehr.**  
    (По будням много движения.)
# Übersetzung
по будням