#reg

| Лицо          | Возвратное местоимение | Форма       | Пример                        |
| ------------- | ---------------------- | ----------- | ----------------------------- |
| ich           | mir                    | merke mir   | Ich **merke mir** das Wort.   |
| **du**        | dir                    | merkst dir  | **Merkst du dir** die Regel?  |
| **sie (она)** | sich                   | merkt sich  | Sie **merkt sich** den Namen. |
| wir           | uns                    | merken uns  | Wir **merken uns** den Weg.   |
| ihr           | euch                   | merkt euch  | **Merkt euch** die Antwort!   |
| sie / Sie     | sich                   | merken sich | Sie **merken sich** alles.    |
# Synonyme

# Verbindung 

# Beispiele
🔹 **Ich kann mir die Wörter nicht merken.**  
(Я не могу запомнить эти слова.)

🔹 **Merkst du dir den Termin?**  
(Ты запомнишь встречу?)

🔹 **Er hat sich den Namen nicht gemerkt.**  
(Он не запомнил имя.)
# Übersetzung
запоминать