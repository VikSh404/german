
| Форма          | Значение                              |
| -------------- | ------------------------------------- |
| **man soll**   | надо, следует (в настоящем)           |
| **man sollte** | следовало бы, сто́ит (вежливо, совет) |

# Verbindung 
[[der Mann]]
[[man]]
# Beispiele
🔹 **Man sollte mehr Wasser trinken.**  
(Следовало бы пить больше воды.)

🔹 **Man sollte nicht zu spät kommen.**  
(Не стоит опаздывать.)

🔹 **Man sollte jeden Tag Deutsch lernen.**  
(Нужно бы учить немецкий каждый день.)
# Übersetzung
следовало бы, сто́ит (вежливо, совет)