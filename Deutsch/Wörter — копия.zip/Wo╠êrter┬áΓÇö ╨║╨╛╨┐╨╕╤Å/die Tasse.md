die Tassen
#nomen
# Synonyme

# Verbindung 

# Beispiele
🔹 **Ich trinke eine Tasse Kaffee.**  
(Я пью чашку кофе.)

🔹 **Die Tasse steht auf dem Tisch.**  
(Чашка стоит на столе.)

🔹 **Möchtest du eine Tasse Tee?**  
(Хочешь чашку чая?)

🔹 **In der Küche gibt es viele Tassen.**  
(На кухне много чашек.)
# Übersetzung
**чашка**