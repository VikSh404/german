die Gerichte
#nomen
# Synonyme

# Verbindung 
[[das Gericht]]
[[der Appetit]]
[[die Küche]]


# Beispiele
- **Mein Lieblingsgericht ist Spaghetti.**  
    (Моё любимое блюдо — спагетти.)
    
- **Heute gibt es drei Gerichte zur Auswahl.**  
    (Сегодня на выбор три блюда.)
    
- **Das Gericht schmeckt sehr gut.**  
    (Блюдо очень вкусное.)
# Übersetzung
блюдо