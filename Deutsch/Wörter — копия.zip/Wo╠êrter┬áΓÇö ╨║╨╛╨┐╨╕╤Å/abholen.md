#reg
- 📍 Дата: 2025-04-20
- ⏰ Время создания: 13:35
# Synonyme

# Verbindung 
[[treffen]]
[[das Kind]]

# Beispiele
- **Ich hole dich um 18 Uhr ab.**  
    (Я заберу тебя в 18:00.)
    
- **Kannst du das Paket abholen?**  
    (Ты можешь забрать посылку?)
    
- **Er hat seine Kinder von der Schule abgeholt.**  
    (Он забрал своих детей из школы.)
    
- **Wir holen unsere Freunde vom Bahnhof ab.**  
    (Мы встречаем друзей на вокзале.)
# Übersetzung
забирать, встречать, подбирать