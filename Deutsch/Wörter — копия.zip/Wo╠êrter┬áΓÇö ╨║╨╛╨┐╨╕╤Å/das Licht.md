#nomen
# Synonyme

# Verbindung 
[[anmachen]]
[[ausmachen]]
# Beispiele

# Übersetzung
