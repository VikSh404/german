ließ, hat gelassen
du - lässt
sie - lässt

#unreg
- 📍 Дата: 2025-04-19
- ⏰ Время создания: 13:29
# Synonyme

# Verbindung 
[[das Haar]]
# Beispiele
### ✅ **Präsens:**

- **Du lässt mich nicht reden.**  
    — Ты не даёшь мне говорить.
    
- **Sie lässt das Fenster offen.**  
    — Она оставляет окно открытым.
    

### ✅ **Präteritum:**

- **Du ließest mich allein.**  
    — Ты оставил меня одного.
    
- **Sie ließ den Hund draußen.**  
    — Она оставила собаку на улице.
    

### ✅ **Perfekt:**

- **Du hast mich warten lassen.**  
    — Ты заставил(а) меня ждать.
    
- **Sie hat die Kinder spielen lassen.**  
    — Она разрешила детям поиграть.
# Übersetzung
- **позволять, разрешать**
    
    > **Ich lasse dich gehen.** – Я позволяю тебе уйти.
    
- **оставлять**
    
    > **Lass mich in Ruhe!** – Оставь меня в покое!
    
- **заставлять что-то сделать / позволить сделать** _(в конструкции с инфинитивом)_
    
    > **Ich lasse mir die Haare schneiden.** – Я подстригаю волосы. (букв. позволяю себе подстричь)