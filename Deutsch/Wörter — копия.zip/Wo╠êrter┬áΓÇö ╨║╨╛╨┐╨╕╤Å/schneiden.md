schnitt, hat geschnitten
du - schneidest
sie - schneidet

#unreg
# Synonyme
[[die Speise]]
# Verbindung 

# Beispiele
1. **Ich schneide das Brot.**  
    — Я режу хлеб.
    
2. **Schneidest du das Gemüse?**  
    — Ты нарезаешь овощи?
    
3. **Er schnitt sich mit dem Messer.**  
    — Он порезался ножом.
    
4. **Wir haben Papier geschnitten.**  
    — Мы нарезали бумагу.
# Übersetzung
резать, нарезать