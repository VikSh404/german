die Töpfe
#nomen
# Synonyme

# Verbindung 
[[das Geschirr]]
# Beispiele
- **Der Topf steht auf dem Herd.**  
    (Кастрюля стоит на плите.)
    
- **Ich koche Suppe in zwei Töpfen.**  
    (Я варю суп в двух кастрюлях.)
    
- **Wo sind die Töpfe?**  
    (Где кастрюли?)
    
- **Sie hat neue Töpfe gekauft.**  
    (Она купила новые кастрюли.)
# Übersetzung
кастрюля, горшок