-

#nomen
# Synonyme

# Verbindung 
[[das Hobby]]
# Beispiele
1. **In meiner Freizeit lese ich gern.**  
    — В свободное время я люблю читать.
    
2. **Hast du heute Freizeit?**  
    — У тебя сегодня есть свободное время?
    
3. **Kinder brauchen mehr Freizeit.**  
    — Детям нужно больше свободного времени.
    
4. **Er hat wenig Freizeit wegen der Arbeit.**  
    — У него мало свободного времени из-за работы.
# Übersetzung
свободное время